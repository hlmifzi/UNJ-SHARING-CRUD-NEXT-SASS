import { useState } from "react"
import useSWR from 'swr'
import axios from 'axios'
import { useForm } from "react-hook-form";
import styles from './contact.module.scss'

const fetcher = url => axios.get(url).then(res => res.data)
const URL_API = "https://gorest.co.in";

export default function Home() {
  const [editId, setEditId] = useState("")
  const { register, handleSubmit, formState: { errors }, setValue } = useForm();

  const { data, error, isLoading } = useSWR(`${URL_API}/public/v2/users`, fetcher, {
    keepPreviousData: true
  })
  if (error) return <div>failed to load</div>

  let config = {
    headers: {
      'Authorization': 'Bearer 60ba5a18321c9bc6009785bda26a148c6f223ccb8b13ea803d10ab57cbe41d74'
    }
  }

  const onSubmit = data => {
    const payload = {
      ...data,
      gender: "male",
      status: "active",
    }
    if (editId) {
      axios.patch(`${URL_API}/public/v2/users/${editId}`, payload, config)
        .then((response) => {
          alert("berhasil mengubah data")
          setEditId("")
          location.reload();
        })
        .catch((error) => {
          const e = error?.response?.data?.[0]
          alert(`${e?.field} ${e?.message}`);
        });
    } else {
      axios.post(`${URL_API}/public/v2/users/`, payload, config)
        .then((response) => {
          alert("berhasil menambahkan")
          location.reload();
        })
        .catch((error) => {
          const e = error?.response?.data?.[0]
          alert(`${e?.field} ${e?.message}`);
        });
    }
  }

  const handleEdit = (data) => {
    setValue('name', data?.name, { shouldValidate: true })
    setValue('email', data?.email, { shouldValidate: true })
    setEditId(data?.id)
  }

  const handleDelete = (id) => {
    axios.delete(`${URL_API}/public/v2/users/${id}`, config)
      .then(() => {
        alert("berhasil menghapus")
        location.reload();
      })
  }

  return (
    <main className={styles.contactContainer}>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className={styles.contactPaperAdd}>
          <h1 className={styles.contactHeader}>
            Tambah Kontak
          </h1>
          <input {...register("name", { required: true })} placeholder="nama" />
          {errors?.name && <small>isi nama cuy</small>}
          <input {...register("email", { required: true })} placeholder="email" />
          <button type="submit">{editId ? "Ubah" : "Tambah"}</button>
        </div>
      </form>
      <div className={styles.contactPaper}>
        <h1 className={styles.contactHeader}>
          Daftar Kontak
        </h1>
        {!isLoading && data?.map((v, i) => {
          return (
            <div key={i} className={styles.contactItem}>
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0x2UNCjwcku2kCU-NZD1JgioT190LmTq61dQYAgeVSh3mmab9YRg7zQY_mLlUn70PmpA&usqp=CAU"
                alt="Vercel Logo"
                className={styles.vercelLogo}
                width={100}
                height={24}
                priority
              />

              <div className={styles.contactDesc}>
                <h3>{v?.name}</h3>
                <p>{v?.email}</p>
              </div>
              <button onClick={() => handleEdit(v)} className={styles.edit}>
                edit
              </button>
              <div onClick={() => handleDelete(v.id)} className={styles.delete}>
                hapus
              </div>
            </div>
          )
        })}
      </div>
    </main >
  )
}
