import Image from 'next/image'
import styles from './contact.module.scss'

export default function Home() {
  return (
    <main className={styles.contactContainer}>
      <div className={styles.contactPaperAdd}>
        <h1 className={styles.contactHeader}>
          Tambah Kontak
        </h1>
        <input placeholder="nama" />
        <input placeholder="email" />
        <button>Tambah</button>
      </div>
      <div className={styles.contactPaper}>
        <h1 className={styles.contactHeader}>
          Daftar Kontak
        </h1>
        <div className={styles.contactItem}>
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0x2UNCjwcku2kCU-NZD1JgioT190LmTq61dQYAgeVSh3mmab9YRg7zQY_mLlUn70PmpA&usqp=CAU"
            alt="Vercel Logo"
            className={styles.vercelLogo}
            width={100}
            height={24}
            priority
          />

          <div className={styles.contactDesc}>
            <h3>nama</h3>
            <p>email</p>
          </div>
          <div className={styles.action}>
            <div className={styles.edit}>
              edit
            </div>
            <div className={styles.delete}>
              hapus
            </div>
          </div>

        </div>
        <div className={styles.contactItem}>
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0x2UNCjwcku2kCU-NZD1JgioT190LmTq61dQYAgeVSh3mmab9YRg7zQY_mLlUn70PmpA&usqp=CAU"
            alt="Vercel Logo"
            className={styles.vercelLogo}
            width={100}
            height={24}
            priority
          />

          <div className={styles.contactDesc}>
            <h3>nama</h3>
            <p>email</p>
          </div>
          <div className={styles.edit}>
            edit
          </div>
        </div>
        <div className={styles.contactItem}>
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0x2UNCjwcku2kCU-NZD1JgioT190LmTq61dQYAgeVSh3mmab9YRg7zQY_mLlUn70PmpA&usqp=CAU"
            alt="Vercel Logo"
            className={styles.vercelLogo}
            width={100}
            height={24}
            priority
          />

          <div className={styles.contactDesc}>
            <h3>nama</h3>
            <p>email</p>
          </div>

          <div className={styles.edit}>
            edit
          </div>
        </div>
        <div className={styles.contactItem}>
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0x2UNCjwcku2kCU-NZD1JgioT190LmTq61dQYAgeVSh3mmab9YRg7zQY_mLlUn70PmpA&usqp=CAU"
            alt="Vercel Logo"
            className={styles.vercelLogo}
            width={100}
            height={24}
            priority
          />

          <div className={styles.contactDesc}>
            <h3>nama</h3>
            <p>email</p>
          </div>

          <div className={styles.edit}>
            edit
          </div>
        </div>
      </div>
    </main>
  )
}
